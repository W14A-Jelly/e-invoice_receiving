This is a directory for storing reports.
The purpose of this file is to make this directory not empty so I can pushed it to github.

