# Sprint 2 #

## Black box HTTP Tests: 7/3/22 -> 9/3/22 ##

Zijie: user register, user logout , user login

Colby: email_retrieve_start , email_retrieve_end

Kian: update email, update password

Elise: set receive email, clear

## Implementation: 7/3/22 -> 11/3/22 ##

Zijie: retriever, end retrieve, validation

Colby: update email, update password

kian: output report, set receive email, clear

Elise: user register, user logout , user login


## Extra Roles ##

Colby: repository structure and jira backlog, database

Zijie: CI integration on github, settings in pylint & coverage

Kian: Communciation, security and performance confluence page

Elise: Assumptions confluence page, server
